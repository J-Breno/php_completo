<?php
require __DIR__ . '/../../fullstackphp/fsphp.php';
fullStackPHPClassName("07.10 - Paginador de resultados");

require __DIR__ . "/../vendor/autoload.php";

/*
 * [ paginator ] https://packagist.org/packages/coffeecode/paginator
 */
fullStackPHPClassSession("paginator", __LINE__);