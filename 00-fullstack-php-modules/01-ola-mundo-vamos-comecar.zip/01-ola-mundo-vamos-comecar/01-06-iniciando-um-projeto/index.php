  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>FSPHP, iniciando um projeto</title>
  </head>
  <body>

  <?php
  $start = "vamos começar!";
  echo "<h1>$start</h1>";
  echo "<div id='js'>Loading...</div>";
  ?>

  </body>
  </html>